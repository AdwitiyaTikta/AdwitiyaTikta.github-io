<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Website - Adwitiya Tikta Pramasti</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 600px;
            width: 100%;
            text-align: center;
        }

        .profile-section {
            margin-bottom: 30px;
        }

        .profile-pic {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            border: 5px solid #667eea;
            margin-bottom: 20px;
            object-fit: cover;
            background: #f0f0f0;
        }

        h1 {
            color: #667eea;
            font-size: 28px;
            margin-bottom: 8px;
        }

        h2 {
            color: #764ba2;
            font-size: 20px;
            margin-bottom: 6px;
        }

        h3 {
            color: #666;
            font-size: 18px;
            margin-bottom: 4px;
        }

        .social-section {
            margin-bottom: 20px;
        }

        .social-links {
            display: flex;
            justify-content: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .social-btn {
            background: #667eea;
            color: white;
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 25px;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .social-btn:hover {
            background: #764ba2;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        $nama = "Adwitiya Tikta Pramasti";
        $nim = "102022400179";
        $fakultas = "Fakultas Rekayasa Industri";
        
        $sosmed = array(
            "X" => "https://x.com/AdwitiyaTikta",
            "GitHub" => "https://github.com/AdwitiyaTikta", 
            "IG" => "https://instagram.com/AdwitiyaTikta",
            "LinkedIn" => "https://www.linkedin.com/in/adwitiya-tikta-31b10a342/"
        );
        ?>

        <div class="profile-section">
            <img src="Foto.jpeg" alt="<?php echo $nama; ?>" class="profile-pic">
            
            <h1><?php echo $nama; ?></h1>
            <h2><?php echo $nim; ?></h2>
            <h3><?php echo $fakultas; ?></h3>
        </div>

        <div class="social-section">
            <div class="social-links">
                <?php
                foreach($sosmed as $platform => $link) {
                    echo '<a href="' . $link . '" target="_blank" class="social-btn">' . $platform . '</a>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>